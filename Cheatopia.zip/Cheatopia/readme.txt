run setup.py in setup folder!
and use:
pip install -r requeriments.txt

HF!